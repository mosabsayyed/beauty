# 13: CANVAS SYSTEM - BACKEND ARCHITECTURE

```yaml
META:
  version: 1.0
  status: FULL_FEATURED_DESIGN
  priority: WOW_FACTOR
  dependencies: [01_DATABASE_FOUNDATION, 04B_CONVERSATION_MEMORY_IMPLEMENTATION, 06_AUTONOMOUS_AGENT_COMPLETE]
  implements: Robust canvas workspace with artifacts, templates, branding, and exports
  file_location: backend/app/services/canvas/
  estimated_complexity: HIGH
  estimated_time: 2-3 weeks
```

---

## PURPOSE

The Canvas system is **THE WOW FACTOR** that differentiates this platform. It transforms the chat interface from basic Q&A into a **powerful workspace** where:

- Reports are generated with client branding
- TwinScience content (64 pieces) is navigable
- Templates ensure consistency
- Exports are publication-ready
- Chat becomes a command center

**Design Philosophy:** Notion + Claude Canvas + Content CMS = Josoor Canvas

---

## SYSTEM ARCHITECTURE

```
┌─────────────────────────────────────────────────────────────────┐
│  USER INTERACTION                                               │
│  Chat: "Create transformation health report for Q4 2024"       │
└────────────────────────┬────────────────────────────────────────┘
                         ↓
┌─────────────────────────────────────────────────────────────────┐
│  CANVAS ORCHESTRATOR (Main Service)                            │
│  ┌────────────────────────────────────────────────────────────┐│
│  │ 1. Parse user intent → artifact type needed                ││
│  │ 2. Select template based on intent                         ││
│  │ 3. Load brand kit for current deployment                   ││
│  │ 4. Generate artifact content (via agent)                   ││
│  │ 5. Render artifact in canvas                               ││
│  │ 6. Store in database with versioning                       ││
│  └────────────────────────────────────────────────────────────┘│
└─────────────────────────────────────────────────────────────────┘
                         ↓
┌─────────────────────────────────────────────────────────────────┐
│  ARTIFACT SERVICES (Specialized Handlers)                       │
│  ┌──────────────┬──────────────┬──────────────┬──────────────┐│
│  │ Report       │ Chart        │ Content      │ Document     ││
│  │ Generator    │ Renderer     │ Navigator    │ Editor       ││
│  └──────────────┴──────────────┴──────────────┴──────────────┘│
└─────────────────────────────────────────────────────────────────┘
                         ↓
┌─────────────────────────────────────────────────────────────────┐
│  TEMPLATE ENGINE                                                │
│  ┌────────────────────────────────────────────────────────────┐│
│  │ Load template → Apply branding → Populate data → Render   ││
│  └────────────────────────────────────────────────────────────┘│
└─────────────────────────────────────────────────────────────────┘
                         ↓
┌─────────────────────────────────────────────────────────────────┐
│  EXPORT ENGINE                                                  │
│  ┌────────────────┬────────────────┬────────────────┐         │
│  │ PDF Generator  │ DOCX Generator │ Image Exporter │         │
│  │ (WeasyPrint)   │ (python-docx)  │ (Pillow)       │         │
│  └────────────────┴────────────────┴────────────────┘         │
└─────────────────────────────────────────────────────────────────┘
                         ↓
┌─────────────────────────────────────────────────────────────────┐
│  STORAGE                                                        │
│  ┌────────────────┬────────────────┬────────────────┐         │
│  │ Artifacts DB   │ Versions DB    │ Brand Kits DB  │         │
│  │ Templates DB   │ Content Files  │ Export Cache   │         │
│  └────────────────┴────────────────┴────────────────┘         │
└─────────────────────────────────────────────────────────────────┘
```

---

## DATABASE MODELS

### **1. Canvas Artifacts Table**

```sql
-- Main artifacts table
CREATE TABLE canvas_artifacts (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    conversation_id VARCHAR(36) REFERENCES conversations(id) ON DELETE CASCADE,
    user_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
    
    -- Artifact metadata
    artifact_type VARCHAR(50) NOT NULL,  -- REPORT, CHART, CONTENT_NAVIGATOR, DOCUMENT, TABLE, PRESENTATION, FORM
    title VARCHAR(500) NOT NULL,
    description TEXT,
    
    -- Content storage
    content JSONB NOT NULL,  -- Full artifact data structure
    
    -- Template and branding
    template_id VARCHAR(100) REFERENCES artifact_templates(id),
    brand_kit_id VARCHAR(100) REFERENCES brand_kits(id),
    
    -- Version control
    version INTEGER DEFAULT 1,
    parent_version_id UUID REFERENCES canvas_artifacts(id),
    
    -- Publishing
    is_published BOOLEAN DEFAULT FALSE,
    published_at TIMESTAMP,
    
    -- Metadata
    tags TEXT[],
    metadata JSONB,  -- Flexible metadata
    
    -- Timestamps
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW(),
    
    CONSTRAINT valid_artifact_type CHECK (
        artifact_type IN ('REPORT', 'CHART', 'CONTENT_NAVIGATOR', 'DOCUMENT', 'TABLE', 'PRESENTATION', 'FORM')
    )
);

-- Indexes for performance
CREATE INDEX idx_artifacts_conversation ON canvas_artifacts(conversation_id);
CREATE INDEX idx_artifacts_user ON canvas_artifacts(user_id);
CREATE INDEX idx_artifacts_type ON canvas_artifacts(artifact_type);
CREATE INDEX idx_artifacts_created ON canvas_artifacts(created_at DESC);
CREATE INDEX idx_artifacts_published ON canvas_artifacts(is_published, published_at);
CREATE INDEX idx_artifacts_tags ON canvas_artifacts USING GIN(tags);

-- Full-text search
CREATE INDEX idx_artifacts_search ON canvas_artifacts USING GIN(
    to_tsvector('english', title || ' ' || COALESCE(description, ''))
);
```

### **2. Artifact Versions Table**

```sql
-- Version history for artifacts
CREATE TABLE artifact_versions (
    id SERIAL PRIMARY KEY,
    artifact_id UUID REFERENCES canvas_artifacts(id) ON DELETE CASCADE,
    version_number INTEGER NOT NULL,
    
    -- Snapshot of content at this version
    content_snapshot JSONB NOT NULL,
    
    -- Change tracking
    change_description TEXT,
    change_type VARCHAR(50),  -- CREATED, EDITED, RESTORED, EXPORTED
    
    -- Metadata
    created_by INTEGER REFERENCES users(id),
    created_at TIMESTAMP DEFAULT NOW(),
    
    UNIQUE(artifact_id, version_number)
);

CREATE INDEX idx_versions_artifact ON artifact_versions(artifact_id, version_number DESC);
```

### **3. Brand Kits Table**

```sql
-- Client branding configurations (ONE per deployment)
CREATE TABLE brand_kits (
    id VARCHAR(100) PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    
    -- Core branding
    primary_color VARCHAR(7) NOT NULL,      -- #00356B
    secondary_color VARCHAR(7),             -- #C8102E
    accent_color VARCHAR(7),                -- #FFD700
    
    -- Logos
    logo_url VARCHAR(500),
    logo_placement VARCHAR(50) DEFAULT 'top-left',  -- top-left, top-center, top-right
    logo_size VARCHAR(50) DEFAULT 'medium',         -- small, medium, large
    
    -- Typography
    font_family VARCHAR(255) DEFAULT 'Arial',
    heading_font VARCHAR(255),
    body_font VARCHAR(255),
    
    -- Report settings
    report_footer TEXT,
    watermark TEXT,
    page_header TEXT,
    
    -- Advanced settings
    config JSONB,  -- Additional flexible settings
    
    -- Status
    is_default BOOLEAN DEFAULT FALSE,
    is_active BOOLEAN DEFAULT TRUE,
    
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);

-- Ensure only one default brand kit
CREATE UNIQUE INDEX idx_brand_kits_default ON brand_kits(is_default) WHERE is_default = TRUE;
```

### **4. Artifact Templates Table**

```sql
-- Reusable templates for artifacts
CREATE TABLE artifact_templates (
    id VARCHAR(100) PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    artifact_type VARCHAR(50) NOT NULL,
    
    -- Template structure
    structure JSONB NOT NULL,  -- Defines sections, layout, placeholders
    default_content JSONB,     -- Default values for placeholders
    
    -- Metadata
    description TEXT,
    category VARCHAR(100),     -- REPORTS, DASHBOARDS, CONTENT, etc.
    thumbnail_url VARCHAR(500),
    
    -- Template settings
    is_system BOOLEAN DEFAULT FALSE,  -- System templates can't be deleted
    is_active BOOLEAN DEFAULT TRUE,
    requires_branding BOOLEAN DEFAULT TRUE,
    
    -- User-created templates (future)
    created_by INTEGER REFERENCES users(id),
    
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX idx_templates_type ON artifact_templates(artifact_type);
CREATE INDEX idx_templates_category ON artifact_templates(category);
```

### **5. TwinScience Content Table**

```sql
-- TwinScience content structure (4 chapters × 4 episodes × 4 pieces = 64 total)
CREATE TABLE twinscience_content (
    id SERIAL PRIMARY KEY,
    
    -- Hierarchy
    chapter_number INTEGER NOT NULL CHECK (chapter_number BETWEEN 1 AND 4),
    episode_number INTEGER NOT NULL CHECK (episode_number BETWEEN 1 AND 4),
    content_type VARCHAR(50) NOT NULL,  -- ARTICLE, PODCAST, VIDEO, STUDY_GUIDE
    
    -- Content metadata
    title VARCHAR(500) NOT NULL,
    description TEXT,
    duration_minutes INTEGER,  -- For video/podcast
    
    -- Content URLs (static files on website)
    article_url VARCHAR(500),      -- HTML article
    podcast_url VARCHAR(500),      -- Audio file
    video_url VARCHAR(500),        -- Video file
    study_guide_url VARCHAR(500),  -- HTML study guide
    images_urls TEXT[],            -- Array of image URLs
    
    -- Display settings
    thumbnail_url VARCHAR(500),
    display_order INTEGER,
    
    -- Status
    is_published BOOLEAN DEFAULT TRUE,
    
    -- Metadata
    tags TEXT[],
    metadata JSONB,
    
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW(),
    
    UNIQUE(chapter_number, episode_number, content_type)
);

CREATE INDEX idx_content_chapter ON twinscience_content(chapter_number, episode_number);
CREATE INDEX idx_content_type ON twinscience_content(content_type);
```

### **6. Content Progress Tracking**

```sql
-- Track user progress through TwinScience content
CREATE TABLE content_progress (
    id SERIAL PRIMARY KEY,
    user_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
    content_id INTEGER REFERENCES twinscience_content(id) ON DELETE CASCADE,
    
    -- Progress
    is_completed BOOLEAN DEFAULT FALSE,
    completion_percentage INTEGER DEFAULT 0 CHECK (completion_percentage BETWEEN 0 AND 100),
    last_position VARCHAR(100),  -- For video/audio (timestamp)
    
    -- Notes
    user_notes TEXT,
    bookmarked BOOLEAN DEFAULT FALSE,
    
    -- Timestamps
    started_at TIMESTAMP,
    completed_at TIMESTAMP,
    last_accessed_at TIMESTAMP DEFAULT NOW(),
    
    UNIQUE(user_id, content_id)
);

CREATE INDEX idx_progress_user ON content_progress(user_id, last_accessed_at DESC);
CREATE INDEX idx_progress_completed ON content_progress(user_id, is_completed);
```

---

## CORE SERVICES

### **1. Canvas Orchestrator**

```python
# backend/app/services/canvas/orchestrator.py
from typing import Dict, Any, Optional, List
from uuid import uuid4
from datetime import datetime
from sqlalchemy.orm import Session

from app.db.models import CanvasArtifact, ArtifactTemplate, BrandKit
from app.services.canvas.artifact_factory import ArtifactFactory
from app.services.canvas.template_engine import TemplateEngine
from app.services.canvas.export_engine import ExportEngine

class CanvasOrchestrator:
    """
    Main orchestrator for canvas operations.
    Coordinates artifact creation, templates, branding, and exports.
    """
    
    def __init__(self, db_session: Session):
        self.db = db_session
        self.artifact_factory = ArtifactFactory(db_session)
        self.template_engine = TemplateEngine(db_session)
        self.export_engine = ExportEngine(db_session)
    
    async def create_artifact(
        self,
        artifact_type: str,
        title: str,
        content: Dict[str, Any],
        conversation_id: str,
        user_id: int,
        template_id: Optional[str] = None,
        description: Optional[str] = None
    ) -> CanvasArtifact:
        """
        Create a new artifact with optional template and branding.
        
        Args:
            artifact_type: REPORT, CHART, CONTENT_NAVIGATOR, etc.
            title: Artifact title
            content: Full artifact data structure
            conversation_id: Associated conversation
            user_id: Creator user ID
            template_id: Optional template to apply
            description: Optional description
        
        Returns:
            CanvasArtifact object
        """
        
        # Load default brand kit
        brand_kit = self.db.query(BrandKit).filter(
            BrandKit.is_default == True,
            BrandKit.is_active == True
        ).first()
        
        # Apply template if specified
        if template_id:
            template = await self.template_engine.load_template(template_id)
            content = await self.template_engine.apply_template(
                template=template,
                content=content,
                brand_kit=brand_kit
            )
        
        # Create artifact
        artifact = CanvasArtifact(
            id=str(uuid4()),
            conversation_id=conversation_id,
            user_id=user_id,
            artifact_type=artifact_type,
            title=title,
            description=description,
            content=content,
            template_id=template_id,
            brand_kit_id=brand_kit.id if brand_kit else None,
            version=1,
            created_at=datetime.utcnow(),
            updated_at=datetime.utcnow()
        )
        
        self.db.add(artifact)
        self.db.commit()
        self.db.refresh(artifact)
        
        # Create initial version snapshot
        await self._create_version_snapshot(artifact, "CREATED", user_id)
        
        return artifact
    
    async def update_artifact(
        self,
        artifact_id: str,
        updates: Dict[str, Any],
        user_id: int,
        change_description: Optional[str] = None
    ) -> CanvasArtifact:
        """
        Update an existing artifact with version tracking.
        """
        artifact = self.db.query(CanvasArtifact).filter(
            CanvasArtifact.id == artifact_id
        ).first()
        
        if not artifact:
            raise ValueError(f"Artifact {artifact_id} not found")
        
        # Update fields
        for key, value in updates.items():
            if hasattr(artifact, key):
                setattr(artifact, key, value)
        
        # Increment version
        artifact.version += 1
        artifact.updated_at = datetime.utcnow()
        
        self.db.commit()
        self.db.refresh(artifact)
        
        # Create version snapshot
        await self._create_version_snapshot(
            artifact, 
            "EDITED", 
            user_id,
            change_description
        )
        
        return artifact
    
    async def export_artifact(
        self,
        artifact_id: str,
        export_format: str,  # PDF, DOCX, PNG, etc.
        include_branding: bool = True
    ) -> bytes:
        """
        Export artifact to specified format.
        
        Returns:
            File bytes
        """
        artifact = self.db.query(CanvasArtifact).filter(
            CanvasArtifact.id == artifact_id
        ).first()
        
        if not artifact:
            raise ValueError(f"Artifact {artifact_id} not found")
        
        # Load brand kit if needed
        brand_kit = None
        if include_branding and artifact.brand_kit_id:
            brand_kit = self.db.query(BrandKit).filter(
                BrandKit.id == artifact.brand_kit_id
            ).first()
        
        # Export based on format
        if export_format.upper() == "PDF":
            return await self.export_engine.export_to_pdf(artifact, brand_kit)
        elif export_format.upper() == "DOCX":
            return await self.export_engine.export_to_docx(artifact, brand_kit)
        elif export_format.upper() == "PNG":
            return await self.export_engine.export_to_image(artifact, brand_kit)
        else:
            raise ValueError(f"Unsupported export format: {export_format}")
    
    async def list_artifacts(
        self,
        user_id: int,
        artifact_type: Optional[str] = None,
        conversation_id: Optional[str] = None,
        limit: int = 50,
        offset: int = 0
    ) -> List[CanvasArtifact]:
        """
        List artifacts with optional filters.
        """
        query = self.db.query(CanvasArtifact).filter(
            CanvasArtifact.user_id == user_id
        )
        
        if artifact_type:
            query = query.filter(CanvasArtifact.artifact_type == artifact_type)
        
        if conversation_id:
            query = query.filter(CanvasArtifact.conversation_id == conversation_id)
        
        query = query.order_by(CanvasArtifact.created_at.desc())
        query = query.limit(limit).offset(offset)
        
        return query.all()
    
    async def _create_version_snapshot(
        self,
        artifact: CanvasArtifact,
        change_type: str,
        user_id: int,
        change_description: Optional[str] = None
    ):
        """
        Create a version snapshot for audit trail.
        """
        from app.db.models import ArtifactVersion
        
        version = ArtifactVersion(
            artifact_id=artifact.id,
            version_number=artifact.version,
            content_snapshot=artifact.content,
            change_type=change_type,
            change_description=change_description,
            created_by=user_id,
            created_at=datetime.utcnow()
        )
        
        self.db.add(version)
        self.db.commit()
```

### **2. Artifact Factory**

```python
# backend/app/services/canvas/artifact_factory.py
from typing import Dict, Any
from sqlalchemy.orm import Session

class ArtifactFactory:
    """
    Factory for creating different artifact types.
    Each artifact type has specific structure and validation.
    """
    
    def __init__(self, db_session: Session):
        self.db = db_session
    
    async def create_report_artifact(
        self,
        title: str,
        sections: List[Dict[str, Any]],
        charts: List[Dict[str, Any]] = None,
        metadata: Dict[str, Any] = None
    ) -> Dict[str, Any]:
        """
        Create report artifact structure.
        
        Structure:
        {
            "type": "REPORT",
            "sections": [
                {
                    "id": "executive_summary",
                    "title": "Executive Summary",
                    "content": "...",
                    "order": 1
                },
                ...
            ],
            "charts": [...],
            "metadata": {...}
        }
        """
        return {
            "type": "REPORT",
            "sections": sections,
            "charts": charts or [],
            "metadata": metadata or {},
            "generated_at": datetime.utcnow().isoformat()
        }
    
    async def create_chart_artifact(
        self,
        chart_type: str,
        data: Dict[str, Any],
        highcharts_config: Dict[str, Any]
    ) -> Dict[str, Any]:
        """
        Create chart artifact structure.
        
        Structure:
        {
            "type": "CHART",
            "chart_type": "spider_chart",
            "data": {...},
            "highcharts_config": {...}
        }
        """
        return {
            "type": "CHART",
            "chart_type": chart_type,
            "data": data,
            "highcharts_config": highcharts_config,
            "generated_at": datetime.utcnow().isoformat()
        }
    
    async def create_content_navigator_artifact(
        self,
        chapter: int,
        episode: int,
        content_items: List[Dict[str, Any]]
    ) -> Dict[str, Any]:
        """
        Create TwinScience content navigator artifact.
        
        Structure:
        {
            "type": "CONTENT_NAVIGATOR",
            "current_chapter": 2,
            "current_episode": 3,
            "content_items": [
                {
                    "type": "ARTICLE",
                    "url": "...",
                    "title": "...",
                    "thumbnail": "..."
                },
                ...
            ]
        }
        """
        return {
            "type": "CONTENT_NAVIGATOR",
            "current_chapter": chapter,
            "current_episode": episode,
            "content_items": content_items,
            "total_chapters": 4,
            "total_episodes_per_chapter": 4,
            "total_content_pieces": 64
        }
    
    async def create_document_artifact(
        self,
        markdown_content: str
    ) -> Dict[str, Any]:
        """
        Create markdown document artifact.
        """
        return {
            "type": "DOCUMENT",
            "format": "markdown",
            "content": markdown_content,
            "word_count": len(markdown_content.split()),
            "generated_at": datetime.utcnow().isoformat()
        }
    
    async def create_table_artifact(
        self,
        headers: List[str],
        rows: List[List[Any]],
        sortable: bool = True,
        filterable: bool = True
    ) -> Dict[str, Any]:
        """
        Create data table artifact.
        """
        return {
            "type": "TABLE",
            "headers": headers,
            "rows": rows,
            "row_count": len(rows),
            "column_count": len(headers),
            "sortable": sortable,
            "filterable": filterable,
            "generated_at": datetime.utcnow().isoformat()
        }
```

---

## TEMPLATE ENGINE

```python
# backend/app/services/canvas/template_engine.py
from typing import Dict, Any, Optional
from sqlalchemy.orm import Session
from jinja2 import Template

from app.db.models import ArtifactTemplate, BrandKit

class TemplateEngine:
    """
    Handles template loading, rendering, and branding application.
    """
    
    def __init__(self, db_session: Session):
        self.db = db_session
    
    async def load_template(self, template_id: str) -> ArtifactTemplate:
        """Load template from database"""
        template = self.db.query(ArtifactTemplate).filter(
            ArtifactTemplate.id == template_id,
            ArtifactTemplate.is_active == True
        ).first()
        
        if not template:
            raise ValueError(f"Template {template_id} not found or inactive")
        
        return template
    
    async def apply_template(
        self,
        template: ArtifactTemplate,
        content: Dict[str, Any],
        brand_kit: Optional[BrandKit] = None
    ) -> Dict[str, Any]:
        """
        Apply template structure to content with branding.
        
        Args:
            template: Template object
            content: Raw content data
            brand_kit: Optional branding to apply
        
        Returns:
            Structured content with template and branding applied
        """
        # Start with template structure
        structured_content = template.structure.copy()
        
        # Apply branding if available
        if brand_kit and template.requires_branding:
            structured_content = await self._apply_branding(
                structured_content,
                brand_kit
            )
        
        # Populate content placeholders
        structured_content = await self._populate_placeholders(
            structured_content,
            content
        )
        
        return structured_content
    
    async def _apply_branding(
        self,
        content: Dict[str, Any],
        brand_kit: BrandKit
    ) -> Dict[str, Any]:
        """
        Apply brand kit styling to content.
        """
        # Add branding metadata
        content["branding"] = {
            "primary_color": brand_kit.primary_color,
            "secondary_color": brand_kit.secondary_color,
            "accent_color": brand_kit.accent_color,
            "logo_url": brand_kit.logo_url,
            "logo_placement": brand_kit.logo_placement,
            "font_family": brand_kit.font_family,
            "heading_font": brand_kit.heading_font or brand_kit.font_family,
            "body_font": brand_kit.body_font or brand_kit.font_family,
            "report_footer": brand_kit.report_footer,
            "watermark": brand_kit.watermark
        }
        
        # Apply colors to chart configurations if present
        if "charts" in content:
            for chart in content["charts"]:
                if "highcharts_config" in chart:
                    chart["highcharts_config"]["colors"] = [
                        brand_kit.primary_color,
                        brand_kit.secondary_color,
                        brand_kit.accent_color
                    ]
        
        return content
    
    async def _populate_placeholders(
        self,
        template_content: Dict[str, Any],
        data: Dict[str, Any]
    ) -> Dict[str, Any]:
        """
        Replace placeholders in template with actual data.
        Uses Jinja2 for template rendering.
        """
        import json
        
        # Convert to JSON string for template processing
        template_str = json.dumps(template_content)
        
        # Create Jinja2 template
        template = Template(template_str)
        
        # Render with data
        rendered = template.render(**data)
        
        # Convert back to dict
        return json.loads(rendered)
    
    async def list_templates(
        self,
        artifact_type: Optional[str] = None,
        category: Optional[str] = None
    ) -> List[ArtifactTemplate]:
        """
        List available templates with optional filters.
        """
        query = self.db.query(ArtifactTemplate).filter(
            ArtifactTemplate.is_active == True
        )
        
        if artifact_type:
            query = query.filter(ArtifactTemplate.artifact_type == artifact_type)
        
        if category:
            query = query.filter(ArtifactTemplate.category == category)
        
        return query.all()
```

---

## EXPORT ENGINE

```python
# backend/app/services/canvas/export_engine.py
from typing import Optional
from io import BytesIO
from sqlalchemy.orm import Session

from app.db.models import CanvasArtifact, BrandKit

class ExportEngine:
    """
    Handles artifact export to various formats (PDF, DOCX, images).
    """
    
    def __init__(self, db_session: Session):
        self.db = db_session
    
    async def export_to_pdf(
        self,
        artifact: CanvasArtifact,
        brand_kit: Optional[BrandKit] = None
    ) -> bytes:
        """
        Export artifact to PDF with high quality.
        Uses WeasyPrint for HTML to PDF conversion.
        """
        from weasyprint import HTML, CSS
        from weasyprint.text.fonts import FontConfiguration
        
        # Generate HTML from artifact
        html_content = await self._generate_html(artifact, brand_kit)
        
        # Generate CSS with branding
        css_content = await self._generate_css(brand_kit) if brand_kit else ""
        
        # Configure fonts
        font_config = FontConfiguration()
        
        # Convert to PDF
        pdf_bytes = HTML(string=html_content).write_pdf(
            stylesheets=[CSS(string=css_content, font_config=font_config)],
            font_config=font_config
        )
        
        return pdf_bytes
    
    async def export_to_docx(
        self,
        artifact: CanvasArtifact,
        brand_kit: Optional[BrandKit] = None
    ) -> bytes:
        """
        Export artifact to DOCX (Microsoft Word).
        Uses python-docx library.
        """
        from docx import Document
        from docx.shared import Inches, Pt, RGBColor
        from docx.enum.text import WD_ALIGN_PARAGRAPH
        
        doc = Document()
        
        # Apply branding if available
        if brand_kit:
            # Set default font
            style = doc.styles['Normal']
            font = style.font
            font.name = brand_kit.font_family or 'Arial'
            font.size = Pt(11)
        
        # Add logo header
        if brand_kit and brand_kit.logo_url:
            # Add logo (would need to download from URL first)
            # doc.add_picture(logo_path, width=Inches(2))
            pass
        
        # Add title
        title = doc.add_heading(artifact.title, level=0)
        title.alignment = WD_ALIGN_PARAGRAPH.CENTER
        
        # Add content based on artifact type
        content = artifact.content
        
        if artifact.artifact_type == "REPORT":
            # Add sections
            for section in content.get("sections", []):
                doc.add_heading(section["title"], level=1)
                doc.add_paragraph(section["content"])
        
        elif artifact.artifact_type == "DOCUMENT":
            # Add markdown content (convert to plain text)
            doc.add_paragraph(content["content"])
        
        elif artifact.artifact_type == "TABLE":
            # Add table
            table = doc.add_table(
                rows=len(content["rows"]) + 1,
                cols=len(content["headers"])
            )
            
            # Add headers
            for i, header in enumerate(content["headers"]):
                table.rows[0].cells[i].text = header
            
            # Add rows
            for i, row in enumerate(content["rows"]):
                for j, cell in enumerate(row):
                    table.rows[i+1].cells[j].text = str(cell)
        
        # Add footer
        if brand_kit and brand_kit.report_footer:
            footer = doc.sections[0].footer
            footer_para = footer.paragraphs[0]
            footer_para.text = brand_kit.report_footer
            footer_para.alignment = WD_ALIGN_PARAGRAPH.CENTER
        
        # Save to bytes
        buffer = BytesIO()
        doc.save(buffer)
        buffer.seek(0)
        
        return buffer.read()
    
    async def export_to_image(
        self,
        artifact: CanvasArtifact,
        brand_kit: Optional[BrandKit] = None,
        format: str = "PNG"
    ) -> bytes:
        """
        Export artifact to image (for charts primarily).
        Uses Pillow for image generation.
        """
        from PIL import Image, ImageDraw, ImageFont
        from io import BytesIO
        
        # For charts, use Highcharts export server
        # For other types, render as image
        
        if artifact.artifact_type == "CHART":
            # Would integrate with Highcharts export server
            # For now, placeholder
            pass
        
        # Placeholder implementation
        img = Image.new('RGB', (1200, 800), color='white')
        draw = ImageDraw.Draw(img)
        
        # Add title
        draw.text((50, 50), artifact.title, fill='black')
        
        buffer = BytesIO()
        img.save(buffer, format=format)
        buffer.seek(0)
        
        return buffer.read()
    
    async def _generate_html(
        self,
        artifact: CanvasArtifact,
        brand_kit: Optional[BrandKit]
    ) -> str:
        """
        Generate HTML representation of artifact.
        """
        content = artifact.content
        branding = content.get("branding", {})
        
        html = f"""
        <!DOCTYPE html>
        <html>
        <head>
            <meta charset="UTF-8">
            <title>{artifact.title}</title>
        </head>
        <body>
        """
        
        # Add logo if present
        if brand_kit and brand_kit.logo_url:
            placement = brand_kit.logo_placement or "top-left"
            html += f'<div class="logo {placement}"><img src="{brand_kit.logo_url}" alt="Logo"/></div>'
        
        # Add title
        html += f'<h1>{artifact.title}</h1>'
        
        # Add content based on type
        if artifact.artifact_type == "REPORT":
            for section in content.get("sections", []):
                html += f'<h2>{section["title"]}</h2>'
                html += f'<div class="section-content">{section["content"]}</div>'
        
        elif artifact.artifact_type == "DOCUMENT":
            # Convert markdown to HTML
            import markdown
            html += markdown.markdown(content["content"])
        
        # Add footer
        if brand_kit and brand_kit.report_footer:
            html += f'<footer>{brand_kit.report_footer}</footer>'
        
        html += """
        </body>
        </html>
        """
        
        return html
    
    async def _generate_css(self, brand_kit: BrandKit) -> str:
        """
        Generate CSS with brand styling.
        """
        css = f"""
        @page {{
            size: A4;
            margin: 2cm;
        }}
        
        body {{
            font-family: '{brand_kit.font_family}', Arial, sans-serif;
            color: #333;
            line-height: 1.6;
        }}
        
        h1, h2, h3 {{
            font-family: '{brand_kit.heading_font or brand_kit.font_family}', Arial, sans-serif;
            color: {brand_kit.primary_color};
        }}
        
        h1 {{
            text-align: center;
            border-bottom: 3px solid {brand_kit.primary_color};
            padding-bottom: 10px;
        }}
        
        .logo {{
            margin-bottom: 20px;
        }}
        
        .logo.top-left {{
            float: left;
        }}
        
        .logo.top-center {{
            text-align: center;
        }}
        
        .logo.top-right {{
            float: right;
        }}
        
        .logo img {{
            max-width: 200px;
            height: auto;
        }}
        
        footer {{
            text-align: center;
            font-size: 10pt;
            color: #666;
            margin-top: 50px;
            border-top: 1px solid {brand_kit.primary_color};
            padding-top: 10px;
        }}
        
        .section-content {{
            margin-bottom: 30px;
        }}
        """
        
        return css
```

---

**CONTINUED IN NEXT MESSAGE... (Running out of character limit)**

This is Part 1 of the Canvas Backend documentation. Shall I continue with:
- Part 2: TwinScience Content Service
- Part 3: API Endpoints
- Part 4: Template Definitions (Weekly/Monthly/Quarterly reports)
- Part 5: Integration with Agent# 13: CANVAS SYSTEM - BACKEND ARCHITECTURE (PART 2)

## PART 2: TWINSCIENCE CONTENT SERVICE

### **TwinScience Content Management**

```python
# backend/app/services/canvas/twinscience_service.py
from typing import Dict, Any, List, Optional
from sqlalchemy.orm import Session
from sqlalchemy import and_

from app.db.models import TwinScienceContent, ContentProgress

class TwinScienceService:
    """
    Manages TwinScience content delivery and progress tracking.
    Handles 64 content pieces (4 chapters × 4 episodes × 4 types).
    """
    
    def __init__(self, db_session: Session):
        self.db = db_session
    
    async def get_all_chapters(self) -> List[Dict[str, Any]]:
        """
        Get complete chapter/episode structure for navigation tree.
        
        Returns:
        [
            {
                "chapter_number": 1,
                "chapter_title": "Digital Foundation",
                "episodes": [
                    {
                        "episode_number": 1,
                        "episode_title": "Understanding Digital Transformation",
                        "content_count": 4
                    },
                    ...
                ]
            },
            ...
        ]
        """
        chapters = []
        
        for chapter_num in range(1, 5):  # 4 chapters
            episodes = []
            
            for episode_num in range(1, 5):  # 4 episodes per chapter
                # Get content pieces for this episode
                content_items = self.db.query(TwinScienceContent).filter(
                    and_(
                        TwinScienceContent.chapter_number == chapter_num,
                        TwinScienceContent.episode_number == episode_num,
                        TwinScienceContent.is_published == True
                    )
                ).all()
                
                if content_items:
                    # Use first item's title as episode title (or derive from chapter/episode)
                    episode_title = self._get_episode_title(chapter_num, episode_num)
                    
                    episodes.append({
                        "episode_number": episode_num,
                        "episode_title": episode_title,
                        "content_count": len(content_items)
                    })
            
            chapters.append({
                "chapter_number": chapter_num,
                "chapter_title": self._get_chapter_title(chapter_num),
                "episodes": episodes,
                "total_episodes": len(episodes)
            })
        
        return chapters
    
    async def get_episode_content(
        self,
        chapter_number: int,
        episode_number: int,
        user_id: Optional[int] = None
    ) -> Dict[str, Any]:
        """
        Get all 4 content pieces for a specific episode with progress.
        
        Returns:
        {
            "chapter_number": 2,
            "episode_number": 3,
            "episode_title": "Measuring Digital Maturity",
            "breadcrumb": "Home > Chapter 2 > Episode 3",
            "content_pieces": [
                {
                    "id": 123,
                    "type": "ARTICLE",
                    "title": "Understanding Digital Maturity Frameworks",
                    "description": "...",
                    "url": "https://...",
                    "thumbnail_url": "...",
                    "duration_minutes": 15,
                    "progress": {
                        "is_completed": true,
                        "completion_percentage": 100
                    }
                },
                ...
            ]
        }
        """
        # Get content items
        content_items = self.db.query(TwinScienceContent).filter(
            and_(
                TwinScienceContent.chapter_number == chapter_number,
                TwinScienceContent.episode_number == episode_number,
                TwinScienceContent.is_published == True
            )
        ).order_by(TwinScienceContent.display_order).all()
        
        if not content_items:
            raise ValueError(f"No content found for Chapter {chapter_number}, Episode {episode_number}")
        
        # Get user progress if user_id provided
        progress_map = {}
        if user_id:
            progress_records = self.db.query(ContentProgress).filter(
                and_(
                    ContentProgress.user_id == user_id,
                    ContentProgress.content_id.in_([c.id for c in content_items])
                )
            ).all()
            
            progress_map = {p.content_id: p for p in progress_records}
        
        # Format content pieces
        content_pieces = []
        for item in content_items:
            progress = progress_map.get(item.id)
            
            # Determine content URL based on type
            content_url = None
            if item.content_type == "ARTICLE":
                content_url = item.article_url
            elif item.content_type == "PODCAST":
                content_url = item.podcast_url
            elif item.content_type == "VIDEO":
                content_url = item.video_url
            elif item.content_type == "STUDY_GUIDE":
                content_url = item.study_guide_url
            
            content_pieces.append({
                "id": item.id,
                "type": item.content_type,
                "title": item.title,
                "description": item.description,
                "url": content_url,
                "thumbnail_url": item.thumbnail_url,
                "duration_minutes": item.duration_minutes,
                "images_urls": item.images_urls or [],
                "progress": {
                    "is_completed": progress.is_completed if progress else False,
                    "completion_percentage": progress.completion_percentage if progress else 0,
                    "last_position": progress.last_position if progress else None
                } if progress else {
                    "is_completed": False,
                    "completion_percentage": 0,
                    "last_position": None
                }
            })
        
        return {
            "chapter_number": chapter_number,
            "episode_number": episode_number,
            "episode_title": self._get_episode_title(chapter_number, episode_number),
            "chapter_title": self._get_chapter_title(chapter_number),
            "breadcrumb": f"Home > {self._get_chapter_title(chapter_number)} > Episode {episode_number}",
            "content_pieces": content_pieces
        }
    
    async def get_content_piece(
        self,
        content_id: int,
        user_id: Optional[int] = None
    ) -> Dict[str, Any]:
        """
        Get single content piece with full details for modal overlay.
        """
        content = self.db.query(TwinScienceContent).filter(
            TwinScienceContent.id == content_id
        ).first()
        
        if not content:
            raise ValueError(f"Content {content_id} not found")
        
        # Get user progress
        progress = None
        if user_id:
            progress = self.db.query(ContentProgress).filter(
                and_(
                    ContentProgress.user_id == user_id,
                    ContentProgress.content_id == content_id
                )
            ).first()
        
        # Determine content URL
        content_url = None
        if content.content_type == "ARTICLE":
            content_url = content.article_url
        elif content.content_type == "PODCAST":
            content_url = content.podcast_url
        elif content.content_type == "VIDEO":
            content_url = content.video_url
        elif content.content_type == "STUDY_GUIDE":
            content_url = content.study_guide_url
        
        return {
            "id": content.id,
            "type": content.content_type,
            "title": content.title,
            "description": content.description,
            "url": content_url,
            "images_urls": content.images_urls or [],
            "duration_minutes": content.duration_minutes,
            "chapter_number": content.chapter_number,
            "episode_number": content.episode_number,
            "progress": {
                "is_completed": progress.is_completed if progress else False,
                "completion_percentage": progress.completion_percentage if progress else 0,
                "last_position": progress.last_position if progress else None,
                "last_accessed_at": progress.last_accessed_at.isoformat() if progress else None
            }
        }
    
    async def update_progress(
        self,
        user_id: int,
        content_id: int,
        completion_percentage: int,
        last_position: Optional[str] = None,
        is_completed: Optional[bool] = None
    ) -> ContentProgress:
        """
        Update user progress for content piece.
        
        Args:
            user_id: User ID
            content_id: Content piece ID
            completion_percentage: 0-100 percentage
            last_position: For video/audio, timestamp like "00:05:32"
            is_completed: Override completion status
        """
        from datetime import datetime
        
        # Get or create progress record
        progress = self.db.query(ContentProgress).filter(
            and_(
                ContentProgress.user_id == user_id,
                ContentProgress.content_id == content_id
            )
        ).first()
        
        if not progress:
            progress = ContentProgress(
                user_id=user_id,
                content_id=content_id,
                started_at=datetime.utcnow()
            )
            self.db.add(progress)
        
        # Update progress
        progress.completion_percentage = completion_percentage
        progress.last_accessed_at = datetime.utcnow()
        
        if last_position:
            progress.last_position = last_position
        
        # Auto-complete if reached 100%
        if completion_percentage >= 100 or is_completed:
            progress.is_completed = True
            if not progress.completed_at:
                progress.completed_at = datetime.utcnow()
        
        self.db.commit()
        self.db.refresh(progress)
        
        return progress
    
    async def get_user_overall_progress(
        self,
        user_id: int
    ) -> Dict[str, Any]:
        """
        Calculate user's overall progress across all TwinScience content.
        
        Returns:
        {
            "total_content_pieces": 64,
            "completed_count": 23,
            "in_progress_count": 5,
            "not_started_count": 36,
            "completion_percentage": 36,
            "by_chapter": [...]
        }
        """
        # Get all progress records for user
        progress_records = self.db.query(ContentProgress).filter(
            ContentProgress.user_id == user_id
        ).all()
        
        completed_count = sum(1 for p in progress_records if p.is_completed)
        in_progress_count = sum(
            1 for p in progress_records 
            if not p.is_completed and p.completion_percentage > 0
        )
        
        total_pieces = 64  # 4 chapters × 4 episodes × 4 types
        not_started_count = total_pieces - len(progress_records)
        
        overall_percentage = int((completed_count / total_pieces) * 100)
        
        # Calculate by chapter
        by_chapter = []
        for chapter_num in range(1, 5):
            chapter_progress = self._calculate_chapter_progress(
                user_id, 
                chapter_num,
                progress_records
            )
            by_chapter.append(chapter_progress)
        
        return {
            "total_content_pieces": total_pieces,
            "completed_count": completed_count,
            "in_progress_count": in_progress_count,
            "not_started_count": not_started_count,
            "completion_percentage": overall_percentage,
            "by_chapter": by_chapter
        }
    
    def _calculate_chapter_progress(
        self,
        user_id: int,
        chapter_number: int,
        progress_records: List[ContentProgress]
    ) -> Dict[str, Any]:
        """Calculate progress for a single chapter"""
        # Get all content for this chapter
        chapter_content = self.db.query(TwinScienceContent).filter(
            TwinScienceContent.chapter_number == chapter_number
        ).all()
        
        content_ids = [c.id for c in chapter_content]
        chapter_progress = [p for p in progress_records if p.content_id in content_ids]
        
        completed = sum(1 for p in chapter_progress if p.is_completed)
        total = len(chapter_content)
        
        return {
            "chapter_number": chapter_number,
            "chapter_title": self._get_chapter_title(chapter_number),
            "completed_count": completed,
            "total_count": total,
            "completion_percentage": int((completed / total) * 100) if total > 0 else 0
        }
    
    def _get_chapter_title(self, chapter_number: int) -> str:
        """Get chapter title (hardcoded or from config)"""
        titles = {
            1: "Digital Foundation",
            2: "Capability Building",
            3: "Transformation Execution",
            4: "Sustainable Innovation"
        }
        return titles.get(chapter_number, f"Chapter {chapter_number}")
    
    def _get_episode_title(self, chapter_number: int, episode_number: int) -> str:
        """Get episode title (would come from database or config)"""
        # Placeholder - in real implementation, this would come from database
        return f"Episode {episode_number}: Digital Maturity Assessment"
```

---

## PART 3: API ENDPOINTS

### **Canvas API Routes**

```python
# backend/app/api/v1/endpoints/canvas.py
from fastapi import APIRouter, Depends, HTTPException, status, UploadFile, File
from fastapi.responses import StreamingResponse
from sqlalchemy.orm import Session
from typing import List, Optional
from io import BytesIO

from app.api.deps import get_db, get_current_user
from app.db.models import User
from app.services.canvas.orchestrator import CanvasOrchestrator
from app.services.canvas.twinscience_service import TwinScienceService
from app.schemas.canvas import (
    ArtifactCreate,
    ArtifactUpdate,
    ArtifactResponse,
    ProgressUpdate,
    ExportRequest
)

router = APIRouter()

# ==================== ARTIFACT MANAGEMENT ====================

@router.post("/artifacts", response_model=ArtifactResponse)
async def create_artifact(
    artifact_data: ArtifactCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """
    Create a new canvas artifact.
    
    Request body:
    {
        "artifact_type": "REPORT",
        "title": "Q4 Transformation Report",
        "content": {...},
        "conversation_id": "conv_123",
        "template_id": "weekly_progress_v1",
        "description": "Quarterly progress report"
    }
    """
    orchestrator = CanvasOrchestrator(db)
    
    artifact = await orchestrator.create_artifact(
        artifact_type=artifact_data.artifact_type,
        title=artifact_data.title,
        content=artifact_data.content,
        conversation_id=artifact_data.conversation_id,
        user_id=current_user.id,
        template_id=artifact_data.template_id,
        description=artifact_data.description
    )
    
    return artifact

@router.get("/artifacts/{artifact_id}", response_model=ArtifactResponse)
async def get_artifact(
    artifact_id: str,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """Get artifact by ID"""
    from app.db.models import CanvasArtifact
    
    artifact = db.query(CanvasArtifact).filter(
        CanvasArtifact.id == artifact_id,
        CanvasArtifact.user_id == current_user.id
    ).first()
    
    if not artifact:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Artifact not found"
        )
    
    return artifact

@router.put("/artifacts/{artifact_id}", response_model=ArtifactResponse)
async def update_artifact(
    artifact_id: str,
    updates: ArtifactUpdate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """
    Update artifact with version tracking.
    
    Request body:
    {
        "content": {...},
        "title": "Updated Title",
        "change_description": "Added section 3"
    }
    """
    orchestrator = CanvasOrchestrator(db)
    
    # Verify ownership
    from app.db.models import CanvasArtifact
    artifact = db.query(CanvasArtifact).filter(
        CanvasArtifact.id == artifact_id,
        CanvasArtifact.user_id == current_user.id
    ).first()
    
    if not artifact:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Artifact not found"
        )
    
    updated_artifact = await orchestrator.update_artifact(
        artifact_id=artifact_id,
        updates=updates.dict(exclude_unset=True),
        user_id=current_user.id,
        change_description=updates.change_description
    )
    
    return updated_artifact

@router.delete("/artifacts/{artifact_id}")
async def delete_artifact(
    artifact_id: str,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """Soft delete artifact"""
    from app.db.models import CanvasArtifact
    
    artifact = db.query(CanvasArtifact).filter(
        CanvasArtifact.id == artifact_id,
        CanvasArtifact.user_id == current_user.id
    ).first()
    
    if not artifact:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Artifact not found"
        )
    
    db.delete(artifact)
    db.commit()
    
    return {"message": "Artifact deleted successfully"}

@router.get("/artifacts", response_model=List[ArtifactResponse])
async def list_artifacts(
    artifact_type: Optional[str] = None,
    conversation_id: Optional[str] = None,
    limit: int = 50,
    offset: int = 0,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """List user's artifacts with filters"""
    orchestrator = CanvasOrchestrator(db)
    
    artifacts = await orchestrator.list_artifacts(
        user_id=current_user.id,
        artifact_type=artifact_type,
        conversation_id=conversation_id,
        limit=limit,
        offset=offset
    )
    
    return artifacts

# ==================== VERSION CONTROL ====================

@router.get("/artifacts/{artifact_id}/versions")
async def get_artifact_versions(
    artifact_id: str,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """Get version history for artifact"""
    from app.db.models import ArtifactVersion, CanvasArtifact
    
    # Verify ownership
    artifact = db.query(CanvasArtifact).filter(
        CanvasArtifact.id == artifact_id,
        CanvasArtifact.user_id == current_user.id
    ).first()
    
    if not artifact:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Artifact not found"
        )
    
    versions = db.query(ArtifactVersion).filter(
        ArtifactVersion.artifact_id == artifact_id
    ).order_by(ArtifactVersion.version_number.desc()).all()
    
    return versions

@router.post("/artifacts/{artifact_id}/restore/{version_number}")
async def restore_version(
    artifact_id: str,
    version_number: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """Restore artifact to specific version"""
    from app.db.models import ArtifactVersion, CanvasArtifact
    
    # Get artifact
    artifact = db.query(CanvasArtifact).filter(
        CanvasArtifact.id == artifact_id,
        CanvasArtifact.user_id == current_user.id
    ).first()
    
    if not artifact:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Artifact not found"
        )
    
    # Get version snapshot
    version = db.query(ArtifactVersion).filter(
        ArtifactVersion.artifact_id == artifact_id,
        ArtifactVersion.version_number == version_number
    ).first()
    
    if not version:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Version {version_number} not found"
        )
    
    # Restore content from snapshot
    orchestrator = CanvasOrchestrator(db)
    restored_artifact = await orchestrator.update_artifact(
        artifact_id=artifact_id,
        updates={"content": version.content_snapshot},
        user_id=current_user.id,
        change_description=f"Restored to version {version_number}"
    )
    
    return restored_artifact

# ==================== EXPORT ====================

@router.post("/artifacts/{artifact_id}/export/pdf")
async def export_to_pdf(
    artifact_id: str,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """
    Export artifact to PDF (direct download).
    Returns file stream for immediate download.
    """
    from app.db.models import CanvasArtifact
    
    artifact = db.query(CanvasArtifact).filter(
        CanvasArtifact.id == artifact_id,
        CanvasArtifact.user_id == current_user.id
    ).first()
    
    if not artifact:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Artifact not found"
        )
    
    orchestrator = CanvasOrchestrator(db)
    pdf_bytes = await orchestrator.export_artifact(
        artifact_id=artifact_id,
        export_format="PDF"
    )
    
    # Return as downloadable file
    filename = f"{artifact.title.replace(' ', '_')}.pdf"
    
    return StreamingResponse(
        BytesIO(pdf_bytes),
        media_type="application/pdf",
        headers={
            "Content-Disposition": f'attachment; filename="{filename}"'
        }
    )

@router.post("/artifacts/{artifact_id}/export/docx")
async def export_to_docx(
    artifact_id: str,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """Export artifact to DOCX (direct download)"""
    from app.db.models import CanvasArtifact
    
    artifact = db.query(CanvasArtifact).filter(
        CanvasArtifact.id == artifact_id,
        CanvasArtifact.user_id == current_user.id
    ).first()
    
    if not artifact:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Artifact not found"
        )
    
    orchestrator = CanvasOrchestrator(db)
    docx_bytes = await orchestrator.export_artifact(
        artifact_id=artifact_id,
        export_format="DOCX"
    )
    
    filename = f"{artifact.title.replace(' ', '_')}.docx"
    
    return StreamingResponse(
        BytesIO(docx_bytes),
        media_type="application/vnd.openxmlformats-officedocument.wordprocessingml.document",
        headers={
            "Content-Disposition": f'attachment; filename="{filename}"'
        }
    )

# ==================== TWINSCIENCE CONTENT ====================

@router.get("/twinscience/chapters")
async def get_twinscience_chapters(
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """
    Get complete chapter/episode structure for navigation tree.
    
    Returns:
    [
        {
            "chapter_number": 1,
            "chapter_title": "Digital Foundation",
            "episodes": [...]
        },
        ...
    ]
    """
    service = TwinScienceService(db)
    chapters = await service.get_all_chapters()
    return chapters

@router.get("/twinscience/episodes/{chapter_number}/{episode_number}")
async def get_episode_content(
    chapter_number: int,
    episode_number: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """
    Get all 4 content pieces for specific episode.
    
    Returns:
    {
        "chapter_number": 2,
        "episode_number": 3,
        "content_pieces": [
            {"type": "ARTICLE", ...},
            {"type": "PODCAST", ...},
            {"type": "VIDEO", ...},
            {"type": "STUDY_GUIDE", ...}
        ]
    }
    """
    service = TwinScienceService(db)
    episode_data = await service.get_episode_content(
        chapter_number=chapter_number,
        episode_number=episode_number,
        user_id=current_user.id
    )
    return episode_data

@router.get("/twinscience/content/{content_id}")
async def get_content_piece(
    content_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """
    Get single content piece for modal overlay.
    Used when user clicks "Read Article" or "Watch Video".
    """
    service = TwinScienceService(db)
    content = await service.get_content_piece(
        content_id=content_id,
        user_id=current_user.id
    )
    return content

@router.post("/twinscience/progress")
async def update_content_progress(
    progress_data: ProgressUpdate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """
    Update user progress for content piece.
    Called periodically while viewing content.
    
    Request body:
    {
        "content_id": 123,
        "completion_percentage": 75,
        "last_position": "00:05:32",  # For video/audio
        "is_completed": false
    }
    """
    service = TwinScienceService(db)
    progress = await service.update_progress(
        user_id=current_user.id,
        content_id=progress_data.content_id,
        completion_percentage=progress_data.completion_percentage,
        last_position=progress_data.last_position,
        is_completed=progress_data.is_completed
    )
    return progress

@router.get("/twinscience/progress/overall")
async def get_overall_progress(
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """
    Get user's overall TwinScience progress.
    Used for progress bar in navigation sidebar.
    
    Returns:
    {
        "total_content_pieces": 64,
        "completed_count": 23,
        "completion_percentage": 36,
        "by_chapter": [...]
    }
    """
    service = TwinScienceService(db)
    progress = await service.get_user_overall_progress(current_user.id)
    return progress

# ==================== TEMPLATES ====================

@router.get("/templates")
async def list_templates(
    artifact_type: Optional[str] = None,
    category: Optional[str] = None,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """
    List available templates.
    
    Query params:
    - artifact_type: REPORT, CHART, DOCUMENT, etc.
    - category: REPORTS, DASHBOARDS, etc.
    """
    from app.services.canvas.template_engine import TemplateEngine
    
    engine = TemplateEngine(db)
    templates = await engine.list_templates(
        artifact_type=artifact_type,
        category=category
    )
    return templates

@router.get("/templates/{template_id}")
async def get_template(
    template_id: str,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """Get template details"""
    from app.services.canvas.template_engine import TemplateEngine
    
    engine = TemplateEngine(db)
    template = await engine.load_template(template_id)
    return template

# ==================== BRANDING ====================

@router.get("/branding")
async def get_brand_kit(
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """Get active brand kit for current deployment"""
    from app.db.models import BrandKit
    
    brand_kit = db.query(BrandKit).filter(
        BrandKit.is_default == True,
        BrandKit.is_active == True
    ).first()
    
    if not brand_kit:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="No active brand kit found"
        )
    
    return brand_kit
```

---

## PART 4: TEMPLATE DEFINITIONS (JSON TDL)

### **1. Weekly Progress Report Template**

```json
{
  "id": "weekly_progress_v1",
  "name": "Weekly Progress Report",
  "artifact_type": "REPORT",
  "category": "REPORTS",
  "description": "Weekly progress report with KPIs and highlights",
  "structure": {
    "layout": {
      "orientation": "portrait",
      "page_size": "A4",
      "margins": {
        "top": 20,
        "right": 15,
        "bottom": 20,
        "left": 15
      }
    },
    "sections": [
      {
        "id": "header",
        "type": "header",
        "order": 1,
        "components": [
          {
            "type": "logo",
            "source": "{{brand.logo_url}}",
            "placement": "{{brand.logo_placement}}",
            "size": "{{brand.logo_size}}"
          },
          {
            "type": "title",
            "content": "{{report_title}}",
            "style": "heading1",
            "alignment": "center"
          },
          {
            "type": "subtitle",
            "content": "Week Ending: {{week_ending}}",
            "style": "subtitle",
            "alignment": "center"
          },
          {
            "type": "divider",
            "color": "{{brand.primary_color}}"
          }
        ]
      },
      {
        "id": "kpis",
        "type": "metrics_section",
        "order": 2,
        "title": "Key Performance Indicators",
        "components": [
          {
            "type": "metric_grid",
            "columns": 3,
            "metrics": "{{kpi_metrics}}",
            "card_style": {
              "border_color": "{{brand.primary_color}}",
              "value_color": "{{brand.primary_color}}",
              "label_color": "#666"
            }
          }
        ]
      },
      {
        "id": "trends",
        "type": "chart_section",
        "order": 3,
        "title": "Weekly Trends",
        "components": [
          {
            "type": "chart",
            "chart_type": "bar",
            "data_source": "{{trend_data}}",
            "height": 300,
            "highcharts_config": {
              "colors": [
                "{{brand.primary_color}}",
                "{{brand.secondary_color}}"
              ]
            }
          }
        ]
      },
      {
        "id": "highlights",
        "type": "content_section",
        "order": 4,
        "title": "Weekly Highlights",
        "components": [
          {
            "type": "bullet_list",
            "items": "{{highlights}}",
            "bullet_color": "{{brand.primary_color}}"
          }
        ]
      },
      {
        "id": "issues",
        "type": "content_section",
        "order": 5,
        "title": "Issues & Blockers",
        "components": [
          {
            "type": "bullet_list",
            "items": "{{issues}}",
            "bullet_color": "#C8102E"
          }
        ]
      },
      {
        "id": "footer",
        "type": "footer",
        "order": 6,
        "components": [
          {
            "type": "text",
            "content": "{{brand.report_footer}}",
            "style": "footer_text",
            "alignment": "center"
          }
        ]
      }
    ]
  },
  "placeholders": [
    {
      "name": "report_title",
      "type": "string",
      "required": true,
      "default": "Weekly Progress Report"
    },
    {
      "name": "week_ending",
      "type": "date",
      "required": true,
      "format": "YYYY-MM-DD"
    },
    {
      "name": "kpi_metrics",
      "type": "array",
      "required": true,
      "schema": {
        "metric_name": "string",
        "value": "number",
        "unit": "string"
      },
      "example": [
        {"metric_name": "Projects", "value": 847, "unit": ""},
        {"metric_name": "Completion", "value": 92, "unit": "%"},
        {"metric_name": "Delayed", "value": 34, "unit": ""}
      ]
    },
    {
      "name": "trend_data",
      "type": "object",
      "required": false,
      "schema": {
        "categories": ["string"],
        "series": [{"name": "string", "data": ["number"]}]
      }
    },
    {
      "name": "highlights",
      "type": "array",
      "required": true,
      "item_type": "string",
      "example": [
        "Completed healthcare portal deployment",
        "Launched education dashboard",
        "5 projects moved to testing phase"
      ]
    },
    {
      "name": "issues",
      "type": "array",
      "required": false,
      "item_type": "string"
    }
  ],
  "styling": {
    "heading1": {
      "font_family": "{{brand.heading_font}}",
      "font_size": 24,
      "font_weight": "bold",
      "color": "{{brand.primary_color}}",
      "margin_bottom": 10
    },
    "subtitle": {
      "font_family": "{{brand.body_font}}",
      "font_size": 14,
      "color": "#666",
      "margin_bottom": 20
    },
    "footer_text": {
      "font_family": "{{brand.body_font}}",
      "font_size": 10,
      "color": "#999"
    }
  },
  "is_system": true,
  "requires_branding": true
}
```

### **2. Monthly Progress Report Template**

```json
{
  "id": "monthly_progress_v1",
  "name": "Monthly Progress Report",
  "artifact_type": "REPORT",
  "category": "REPORTS",
  "description": "Comprehensive monthly progress with detailed analytics",
  "structure": {
    "layout": {
      "orientation": "portrait",
      "page_size": "A4",
      "margins": {"top": 20, "right": 15, "bottom": 20, "left": 15}
    },
    "sections": [
      {
        "id": "header",
        "type": "header",
        "order": 1,
        "components": [
          {"type": "logo", "source": "{{brand.logo_url}}"},
          {"type": "title", "content": "Monthly Progress Report - {{month_name}} {{year}}", "style": "heading1"},
          {"type": "divider", "color": "{{brand.primary_color}}"}
        ]
      },
      {
        "id": "executive_summary",
        "type": "content_section",
        "order": 2,
        "title": "Executive Summary",
        "components": [
          {"type": "paragraph", "content": "{{executive_summary}}"}
        ]
      },
      {
        "id": "kpis",
        "type": "metrics_section",
        "order": 3,
        "title": "Key Performance Indicators",
        "components": [
          {"type": "metric_grid", "columns": 4, "metrics": "{{kpi_metrics}}"}
        ]
      },
      {
        "id": "trends",
        "type": "chart_section",
        "order": 4,
        "title": "Monthly Trends",
        "components": [
          {"type": "chart", "chart_type": "line", "data_source": "{{monthly_trends}}"}
        ]
      },
      {
        "id": "sector_breakdown",
        "type": "chart_section",
        "order": 5,
        "title": "Progress by Sector",
        "components": [
          {"type": "chart", "chart_type": "bar", "data_source": "{{sector_data}}"}
        ]
      },
      {
        "id": "achievements",
        "type": "content_section",
        "order": 6,
        "title": "Key Achievements",
        "components": [
          {"type": "bullet_list", "items": "{{achievements}}"}
        ]
      },
      {
        "id": "challenges",
        "type": "content_section",
        "order": 7,
        "title": "Challenges & Mitigation",
        "components": [
          {"type": "table", "data_source": "{{challenges_table}}"}
        ]
      },
      {
        "id": "footer",
        "type": "footer",
        "order": 8,
        "components": [
          {"type": "text", "content": "{{brand.report_footer}}"}
        ]
      }
    ]
  },
  "placeholders": [
    {"name": "month_name", "type": "string", "required": true},
    {"name": "year", "type": "number", "required": true},
    {"name": "executive_summary", "type": "string", "required": true},
    {"name": "kpi_metrics", "type": "array", "required": true},
    {"name": "monthly_trends", "type": "object", "required": false},
    {"name": "sector_data", "type": "object", "required": false},
    {"name": "achievements", "type": "array", "required": true},
    {"name": "challenges_table", "type": "array", "required": false}
  ],
  "is_system": true,
  "requires_branding": true
}
```

### **3. Adaa Quarterly Report Template**

```json
{
  "id": "adaa_quarterly_v1",
  "name": "Adaa Quarterly Report",
  "artifact_type": "REPORT",
  "category": "REPORTS",
  "description": "Sector-specific quarterly progress aligned with Adaa framework",
  "structure": {
    "layout": {
      "orientation": "portrait",
      "page_size": "A4",
      "margins": {"top": 20, "right": 15, "bottom": 20, "left": 15}
    },
    "sections": [
      {
        "id": "header",
        "type": "header",
        "order": 1,
        "components": [
          {"type": "logo", "source": "{{brand.logo_url}}"},
          {"type": "title", "content": "Adaa Performance Report", "style": "heading1"},
          {"type": "subtitle", "content": "{{quarter}} {{year}} - {{sector_name}}", "style": "subtitle"}
        ]
      },
      {
        "id": "adaa_metrics",
        "type": "metrics_section",
        "order": 2,
        "title": "Adaa Performance Metrics",
        "components": [
          {"type": "metric_grid", "columns": 3, "metrics": "{{adaa_kpis}}"}
        ]
      },
      {
        "id": "project_status",
        "type": "table_section",
        "order": 3,
        "title": "Project Status Overview",
        "components": [
          {"type": "table", "data_source": "{{project_status_table}}"}
        ]
      },
      {
        "id": "strategic_initiatives",
        "type": "content_section",
        "order": 4,
        "title": "Strategic Initiatives",
        "components": [
          {"type": "numbered_list", "items": "{{strategic_initiatives}}"}
        ]
      },
      {
        "id": "sector_insights",
        "type": "chart_section",
        "order": 5,
        "title": "Sector Insights",
        "components": [
          {"type": "chart", "chart_type": "spider", "data_source": "{{sector_radar}}"}
        ]
      },
      {
        "id": "recommendations",
        "type": "content_section",
        "order": 6,
        "title": "Recommendations",
        "components": [
          {"type": "bullet_list", "items": "{{recommendations}}"}
        ]
      }
    ]
  },
  "placeholders": [
    {"name": "quarter", "type": "string", "required": true, "example": "Q1"},
    {"name": "year", "type": "number", "required": true},
    {"name": "sector_name", "type": "string", "required": true},
    {"name": "adaa_kpis", "type": "array", "required": true},
    {"name": "project_status_table", "type": "array", "required": true},
    {"name": "strategic_initiatives", "type": "array", "required": true},
    {"name": "sector_radar", "type": "object", "required": false},
    {"name": "recommendations", "type": "array", "required": true}
  ],
  "is_system": true,
  "requires_branding": true
}
```

### **4. Quarterly Business Review (QBR) Template**

```json
{
  "id": "qbr_v1",
  "name": "Quarterly Business Review",
  "artifact_type": "REPORT",
  "category": "REPORTS",
  "description": "Executive-level quarterly business review with strategic insights",
  "structure": {
    "layout": {
      "orientation": "portrait",
      "page_size": "A4",
      "margins": {"top": 20, "right": 15, "bottom": 20, "left": 15}
    },
    "sections": [
      {
        "id": "cover",
        "type": "cover_page",
        "order": 1,
        "components": [
          {"type": "logo", "source": "{{brand.logo_url}}", "size": "large"},
          {"type": "title", "content": "Quarterly Business Review", "style": "cover_title"},
          {"type": "subtitle", "content": "{{quarter}} {{year}}", "style": "cover_subtitle"}
        ]
      },
      {
        "id": "executive_summary",
        "type": "content_section",
        "order": 2,
        "title": "Executive Summary",
        "components": [
          {"type": "paragraph", "content": "{{exec_summary}}"}
        ]
      },
      {
        "id": "financial_highlights",
        "type": "metrics_section",
        "order": 3,
        "title": "Financial Highlights",
        "components": [
          {"type": "metric_grid", "columns": 4, "metrics": "{{financial_metrics}}"}
        ]
      },
      {
        "id": "portfolio_health",
        "type": "chart_section",
        "order": 4,
        "title": "Portfolio Health",
        "components": [
          {"type": "chart", "chart_type": "donut", "data_source": "{{portfolio_distribution}}"}
        ]
      },
      {
        "id": "strategic_objectives",
        "type": "content_section",
        "order": 5,
        "title": "Strategic Objectives Progress",
        "components": [
          {"type": "table", "data_source": "{{objectives_table}}"}
        ]
      },
      {
        "id": "risk_assessment",
        "type": "content_section",
        "order": 6,
        "title": "Risk Assessment",
        "components": [
          {"type": "table", "data_source": "{{risk_table}}"}
        ]
      },
      {
        "id": "next_quarter",
        "type": "content_section",
        "order": 7,
        "title": "Next Quarter Priorities",
        "components": [
          {"type": "numbered_list", "items": "{{next_quarter_priorities}}"}
        ]
      }
    ]
  },
  "placeholders": [
    {"name": "quarter", "type": "string", "required": true},
    {"name": "year", "type": "number", "required": true},
    {"name": "exec_summary", "type": "string", "required": true},
    {"name": "financial_metrics", "type": "array", "required": true},
    {"name": "portfolio_distribution", "type": "object", "required": false},
    {"name": "objectives_table", "type": "array", "required": true},
    {"name": "risk_table", "type": "array", "required": false},
    {"name": "next_quarter_priorities", "type": "array", "required": true}
  ],
  "is_system": true,
  "requires_branding": true
}
```

---

**CONTINUED IN PART 3...**
# 13: CANVAS SYSTEM - BACKEND ARCHITECTURE (PART 3)

## PART 5: AGENT INTEGRATION

### **How Autonomous Agent Creates Canvas Artifacts**

```python
# backend/app/services/autonomous_agent.py (Enhancement)

from app.services.canvas.orchestrator import CanvasOrchestrator
from app.services.canvas.artifact_factory import ArtifactFactory

class AutonomousAgent:
    """
    Enhanced autonomous agent with canvas artifact creation.
    Layer 4 (Visualization) now creates canvas artifacts.
    """
    
    def __init__(self, db_session: Session):
        self.db = db_session
        # ... existing initialization ...
        self.canvas_orchestrator = CanvasOrchestrator(db_session)
        self.artifact_factory = ArtifactFactory(db_session)
    
    async def layer_4_visualization(
        self,
        analysis_results: Dict[str, Any],
        conversation_id: str,
        user_id: int
    ) -> Dict[str, Any]:
        """
        Layer 4: Visualization & Presentation
        NOW WITH CANVAS ARTIFACT CREATION
        
        Decision tree:
        1. Does output need rich formatting? → Create canvas artifact
        2. Is output complex report? → Use template + canvas
        3. Is output simple chart? → Create chart artifact
        4. Is output data table? → Create table artifact
        5. Otherwise → Return text response
        """
        
        # Determine output type
        output_type = self._determine_output_type(analysis_results)
        
        if output_type == "REPORT":
            # Create report artifact with template
            artifact = await self._create_report_artifact(
                analysis_results,
                conversation_id,
                user_id
            )
            
            return {
                "response_type": "canvas_artifact",
                "artifact_id": artifact.id,
                "artifact_type": "REPORT",
                "preview_url": f"/canvas/artifacts/{artifact.id}",
                "text_summary": self._generate_summary(analysis_results)
            }
        
        elif output_type == "CHART":
            # Create standalone chart artifact
            artifact = await self._create_chart_artifact(
                analysis_results,
                conversation_id,
                user_id
            )
            
            return {
                "response_type": "canvas_artifact",
                "artifact_id": artifact.id,
                "artifact_type": "CHART",
                "preview_url": f"/canvas/artifacts/{artifact.id}",
                "text_summary": self._generate_summary(analysis_results)
            }
        
        elif output_type == "TABLE":
            # Create data table artifact
            artifact = await self._create_table_artifact(
                analysis_results,
                conversation_id,
                user_id
            )
            
            return {
                "response_type": "canvas_artifact",
                "artifact_id": artifact.id,
                "artifact_type": "TABLE",
                "preview_url": f"/canvas/artifacts/{artifact.id}",
                "text_summary": self._generate_summary(analysis_results)
            }
        
        else:
            # Simple text response (no canvas needed)
            return {
                "response_type": "text",
                "content": self._format_text_response(analysis_results)
            }
    
    def _determine_output_type(self, analysis_results: Dict[str, Any]) -> str:
        """
        Intelligent detection of output type based on analysis results.
        Uses heuristics + LLM to determine best presentation format.
        """
        
        # Heuristic rules
        if "sections" in analysis_results and len(analysis_results["sections"]) > 2:
            return "REPORT"
        
        if "chart_config" in analysis_results:
            return "CHART"
        
        if "table_data" in analysis_results and len(analysis_results["table_data"]) > 5:
            return "TABLE"
        
        # Use LLM for ambiguous cases
        prompt = f"""
        Determine the best output format for this analysis:
        
        Analysis: {json.dumps(analysis_results, indent=2)}
        
        Options: REPORT, CHART, TABLE, TEXT
        Return only the format name.
        """
        
        llm_response = self.llm_provider.chat_completion(
            messages=[{"role": "user", "content": prompt}],
            temperature=0.1
        )
        
        return llm_response.strip().upper()
    
    async def _create_report_artifact(
        self,
        analysis_results: Dict[str, Any],
        conversation_id: str,
        user_id: int
    ) -> CanvasArtifact:
        """
        Create report artifact from analysis results.
        Automatically selects appropriate template.
        """
        
        # Detect report type from analysis
        report_type = self._detect_report_type(analysis_results)
        
        # Select template
        template_map = {
            "weekly": "weekly_progress_v1",
            "monthly": "monthly_progress_v1",
            "quarterly": "adaa_quarterly_v1",
            "qbr": "qbr_v1"
        }
        template_id = template_map.get(report_type, "weekly_progress_v1")
        
        # Extract data for template placeholders
        template_data = self._extract_template_data(analysis_results, report_type)
        
        # Build report content
        report_content = await self.artifact_factory.create_report_artifact(
            title=template_data["title"],
            sections=template_data["sections"],
            charts=template_data.get("charts", []),
            metadata=template_data.get("metadata", {})
        )
        
        # Create artifact
        artifact = await self.canvas_orchestrator.create_artifact(
            artifact_type="REPORT",
            title=template_data["title"],
            content=report_content,
            conversation_id=conversation_id,
            user_id=user_id,
            template_id=template_id,
            description=template_data.get("description")
        )
        
        return artifact
    
    async def _create_chart_artifact(
        self,
        analysis_results: Dict[str, Any],
        conversation_id: str,
        user_id: int
    ) -> CanvasArtifact:
        """Create standalone chart artifact"""
        
        chart_data = analysis_results.get("chart_config", {})
        
        chart_content = await self.artifact_factory.create_chart_artifact(
            chart_type=chart_data.get("type", "bar"),
            data=chart_data.get("data", {}),
            highcharts_config=chart_data.get("highcharts_config", {})
        )
        
        artifact = await self.canvas_orchestrator.create_artifact(
            artifact_type="CHART",
            title=chart_data.get("title", "Analysis Chart"),
            content=chart_content,
            conversation_id=conversation_id,
            user_id=user_id
        )
        
        return artifact
    
    async def _create_table_artifact(
        self,
        analysis_results: Dict[str, Any],
        conversation_id: str,
        user_id: int
    ) -> CanvasArtifact:
        """Create data table artifact"""
        
        table_data = analysis_results.get("table_data", {})
        
        table_content = await self.artifact_factory.create_table_artifact(
            headers=table_data.get("headers", []),
            rows=table_data.get("rows", []),
            sortable=True,
            filterable=True
        )
        
        artifact = await self.canvas_orchestrator.create_artifact(
            artifact_type="TABLE",
            title=table_data.get("title", "Data Table"),
            content=table_content,
            conversation_id=conversation_id,
            user_id=user_id
        )
        
        return artifact
    
    def _detect_report_type(self, analysis_results: Dict[str, Any]) -> str:
        """
        Detect report type from analysis results.
        Uses keywords, timeframe, and content structure.
        """
        
        # Extract timeframe indicators
        content_str = json.dumps(analysis_results).lower()
        
        if "week" in content_str or "weekly" in content_str:
            return "weekly"
        elif "month" in content_str or "monthly" in content_str:
            return "monthly"
        elif "quarter" in content_str or "quarterly" in content_str:
            if "adaa" in content_str or "sector" in content_str:
                return "quarterly"
            else:
                return "qbr"
        else:
            return "weekly"  # Default
    
    def _extract_template_data(
        self,
        analysis_results: Dict[str, Any],
        report_type: str
    ) -> Dict[str, Any]:
        """
        Extract data from analysis results to populate template placeholders.
        Maps analysis output to template requirements.
        """
        
        if report_type == "weekly":
            return {
                "title": analysis_results.get("title", "Weekly Progress Report"),
                "description": "Weekly progress report",
                "sections": [
                    {
                        "id": "kpis",
                        "title": "Key Performance Indicators",
                        "content": "",
                        "order": 1,
                        "data": {
                            "kpi_metrics": analysis_results.get("kpis", [])
                        }
                    },
                    {
                        "id": "highlights",
                        "title": "Weekly Highlights",
                        "content": "",
                        "order": 2,
                        "data": {
                            "highlights": analysis_results.get("highlights", [])
                        }
                    }
                ],
                "charts": analysis_results.get("charts", []),
                "metadata": {
                    "week_ending": analysis_results.get("week_ending"),
                    "report_type": "weekly"
                }
            }
        
        elif report_type == "monthly":
            return {
                "title": f"Monthly Progress Report - {analysis_results.get('month')}",
                "description": "Comprehensive monthly progress",
                "sections": [
                    {
                        "id": "executive_summary",
                        "title": "Executive Summary",
                        "content": analysis_results.get("summary", ""),
                        "order": 1
                    },
                    {
                        "id": "kpis",
                        "title": "Key Performance Indicators",
                        "content": "",
                        "order": 2,
                        "data": {
                            "kpi_metrics": analysis_results.get("kpis", [])
                        }
                    }
                ],
                "charts": analysis_results.get("charts", []),
                "metadata": {
                    "month_name": analysis_results.get("month"),
                    "year": analysis_results.get("year"),
                    "report_type": "monthly"
                }
            }
        
        # Add more report types as needed...
        
        return {}
    
    def _generate_summary(self, analysis_results: Dict[str, Any]) -> str:
        """
        Generate text summary for chat display.
        This appears in chat before user clicks to expand canvas.
        """
        summary_parts = []
        
        if "kpis" in analysis_results:
            summary_parts.append(f"📊 {len(analysis_results['kpis'])} key metrics analyzed")
        
        if "highlights" in analysis_results:
            summary_parts.append(f"✨ {len(analysis_results['highlights'])} highlights")
        
        if "charts" in analysis_results:
            summary_parts.append(f"📈 {len(analysis_results['charts'])} visualizations")
        
        return " | ".join(summary_parts)
```

### **Agent Prompts for Canvas Creation**

```python
# Layer 4 Visualization Prompt (Enhanced)
LAYER_4_PROMPT = """
You are Layer 4: Visualization & Presentation.

INPUT: Analysis results from Layer 3
OUTPUT: Canvas artifact specification OR text response

CANVAS ARTIFACT TYPES:
1. REPORT - Multi-section formal report with branding
2. CHART - Standalone interactive visualization
3. TABLE - Sortable/filterable data table
4. DOCUMENT - Rich text markdown document

DECISION CRITERIA:
- Use REPORT if: Multiple sections, formal presentation, executive audience
- Use CHART if: Single visualization, trends/comparisons, quick insight
- Use TABLE if: Large dataset, need filtering/sorting, detailed exploration
- Use TEXT if: Simple answer, no visual needed, conversational

TEMPLATES AVAILABLE:
- weekly_progress_v1: Weekly reports with KPIs and highlights
- monthly_progress_v1: Monthly comprehensive reports
- adaa_quarterly_v1: Sector-specific quarterly reports
- qbr_v1: Executive quarterly business reviews

When creating canvas artifacts:
1. Detect report type from analysis context
2. Select appropriate template
3. Extract data for template placeholders
4. Structure content in sections
5. Include charts/tables as components

Analysis Results:
{analysis_results}

Generate canvas artifact specification:
{{
  "output_type": "REPORT|CHART|TABLE|TEXT",
  "template_id": "template_id_if_report",
  "title": "Artifact title",
  "sections": [...],
  "charts": [...],
  "summary": "Brief text summary for chat"
}}
"""
```

---

## PART 6: EMBED VS LINK RECOMMENDATION

### **Technical Analysis: TwinScience Content Delivery**

**Content Storage Strategy:**

#### **Articles & Study Guides (HTML)**
- **Storage:** PostgreSQL database (TEXT column)
- **Delivery:** Direct embed in modal overlay
- **Rationale:** 
  - Small size (~10-50KB HTML)
  - Fast retrieval from database
  - No external dependencies
  - Can apply custom styling
  - Works offline if cached

**Implementation:**
```python
# Store HTML directly in database
article_html = """
<article>
  <h1>Understanding Digital Maturity</h1>
  <p>Digital transformation...</p>
  <img src="https://cdn.josoor.sa/images/maturity-model.png" />
</article>
"""

# Render in modal
@router.get("/twinscience/content/{content_id}/html")
async def get_article_html(content_id: int):
    content = db.query(TwinScienceContent).get(content_id)
    return HTMLResponse(content=content.article_url)  # article_url contains HTML
```

#### **Images (Conceptual Diagrams)**
- **Storage:** Object storage (Supabase Storage / S3)
- **Delivery:** Link via CDN URLs
- **Rationale:**
  - Scalable storage
  - CDN distribution (fast loading)
  - Image optimization (WebP, compression)
  - No database bloat

**Implementation:**
```python
# Store URLs in database
images_urls = [
    "https://cdn.josoor.sa/twinscience/ch2-ep3-diagram1.webp",
    "https://cdn.josoor.sa/twinscience/ch2-ep3-diagram2.webp"
]

# Embed in HTML
<img src="{{image_url}}" alt="Maturity Model" loading="lazy" />
```

#### **Audio Podcasts**
- **Storage:** Object storage
- **Delivery:** Streaming URL (inline HTML5 player)
- **Rationale:**
  - Large files (20-50MB per podcast)
  - Streaming support required
  - Cannot embed binary in database
  - CDN reduces latency

**Implementation:**
```python
# HTML5 audio player
<audio controls>
  <source src="https://cdn.josoor.sa/twinscience/ch2-ep3-podcast.mp3" type="audio/mpeg">
  Your browser does not support audio.
</audio>
```

#### **Video Presentations**
- **Storage:** Object storage (or YouTube)
- **Delivery:** Streaming URL (inline HTML5 player or YouTube embed)
- **Rationale:**
  - Very large files (100-500MB)
  - Streaming mandatory
  - Adaptive bitrate (if using video platform)
  - Resume playback support

**Implementation:**
```python
# HTML5 video player
<video controls width="100%">
  <source src="https://cdn.josoor.sa/twinscience/ch2-ep3-video.mp4" type="video/mp4">
</video>

# OR YouTube embed
<iframe 
  width="100%" 
  height="500px" 
  src="https://www.youtube.com/embed/VIDEO_ID" 
  frameborder="0" 
  allowfullscreen>
</iframe>
```

### **Recommendation Summary**

| Content Type | Storage | Delivery Method | In Modal |
|--------------|---------|-----------------|----------|
| Articles | PostgreSQL | Embed HTML | ✅ Yes |
| Study Guides | PostgreSQL | Embed HTML | ✅ Yes |
| Images | Object Storage | Link via CDN | ✅ Embed in HTML |
| Audio | Object Storage | Stream via CDN | ✅ Inline player |
| Video | Object Storage | Stream via CDN | ✅ Inline player |

**Key Benefits:**
- ✅ Fast loading (CDN for media)
- ✅ Scalable (object storage for large files)
- ✅ Maintainable (HTML in database easy to update)
- ✅ Cost-effective (no redundant storage)
- ✅ Offline-capable (HTML cached, media streaming)

---

## PART 7: TESTING & PERFORMANCE

### **Canvas-Specific Test Cases**

```python
# tests/test_canvas_orchestrator.py
import pytest
from app.services.canvas.orchestrator import CanvasOrchestrator

@pytest.mark.asyncio
async def test_create_report_artifact(db_session, test_user):
    """Test report artifact creation with template"""
    orchestrator = CanvasOrchestrator(db_session)
    
    artifact = await orchestrator.create_artifact(
        artifact_type="REPORT",
        title="Test Weekly Report",
        content={
            "sections": [
                {"title": "KPIs", "content": "Test content"}
            ]
        },
        conversation_id="test_conv_123",
        user_id=test_user.id,
        template_id="weekly_progress_v1"
    )
    
    assert artifact.id is not None
    assert artifact.artifact_type == "REPORT"
    assert artifact.version == 1
    assert artifact.template_id == "weekly_progress_v1"

@pytest.mark.asyncio
async def test_update_artifact_versioning(db_session, test_artifact):
    """Test version control on artifact updates"""
    orchestrator = CanvasOrchestrator(db_session)
    
    updated = await orchestrator.update_artifact(
        artifact_id=test_artifact.id,
        updates={"title": "Updated Title"},
        user_id=test_artifact.user_id,
        change_description="Updated title"
    )
    
    assert updated.version == 2
    assert updated.title == "Updated Title"
    
    # Check version snapshot created
    versions = db_session.query(ArtifactVersion).filter(
        ArtifactVersion.artifact_id == test_artifact.id
    ).all()
    
    assert len(versions) == 2  # Initial + update

@pytest.mark.asyncio
async def test_export_to_pdf(db_session, test_artifact):
    """Test PDF export"""
    orchestrator = CanvasOrchestrator(db_session)
    
    pdf_bytes = await orchestrator.export_artifact(
        artifact_id=test_artifact.id,
        export_format="PDF"
    )
    
    assert len(pdf_bytes) > 0
    assert pdf_bytes[:4] == b'%PDF'  # PDF magic number

@pytest.mark.asyncio
async def test_twinscience_progress_tracking(db_session, test_user, test_content):
    """Test content progress tracking"""
    from app.services.canvas.twinscience_service import TwinScienceService
    
    service = TwinScienceService(db_session)
    
    # Update progress
    progress = await service.update_progress(
        user_id=test_user.id,
        content_id=test_content.id,
        completion_percentage=75,
        last_position="00:05:32"
    )
    
    assert progress.completion_percentage == 75
    assert progress.last_position == "00:05:32"
    assert progress.is_completed == False
    
    # Complete content
    progress = await service.update_progress(
        user_id=test_user.id,
        content_id=test_content.id,
        completion_percentage=100
    )
    
    assert progress.is_completed == True
    assert progress.completed_at is not None

@pytest.mark.asyncio
async def test_template_placeholder_population(db_session):
    """Test template engine placeholder population"""
    from app.services.canvas.template_engine import TemplateEngine
    
    engine = TemplateEngine(db_session)
    
    template_content = {
        "title": "{{report_title}}",
        "sections": [
            {"content": "Week ending: {{week_ending}}"}
        ]
    }
    
    data = {
        "report_title": "Test Report",
        "week_ending": "2024-03-29"
    }
    
    result = await engine._populate_placeholders(template_content, data)
    
    assert result["title"] == "Test Report"
    assert result["sections"][0]["content"] == "Week ending: 2024-03-29"
```

### **Performance Optimization**

```python
# Performance considerations for canvas system

# 1. ARTIFACT LOADING (Database Queries)
# Optimize with proper indexing and query patterns

async def get_artifact_with_relations(artifact_id: str, db: Session):
    """
    Load artifact with all relations in single query.
    Uses joinedload to avoid N+1 queries.
    """
    from sqlalchemy.orm import joinedload
    
    artifact = db.query(CanvasArtifact)\
        .options(
            joinedload(CanvasArtifact.template),
            joinedload(CanvasArtifact.brand_kit)
        )\
        .filter(CanvasArtifact.id == artifact_id)\
        .first()
    
    return artifact

# 2. EXPORT GENERATION (CPU-Intensive)
# Use background tasks for large exports

from fastapi import BackgroundTasks

@router.post("/artifacts/{artifact_id}/export/pdf/async")
async def export_pdf_async(
    artifact_id: str,
    background_tasks: BackgroundTasks,
    db: Session = Depends(get_db)
):
    """
    Async PDF export for large reports.
    Returns task_id immediately, user polls for completion.
    """
    task_id = str(uuid4())
    
    background_tasks.add_task(
        generate_pdf_background,
        task_id=task_id,
        artifact_id=artifact_id,
        db=db
    )
    
    return {"task_id": task_id, "status": "processing"}

# 3. TWINSCIENCE CONTENT LOADING
# Cache chapter structure (rarely changes)

from functools import lru_cache

@lru_cache(maxsize=1)
async def get_cached_chapter_structure():
    """
    Cache chapter structure for 1 hour.
    Invalidate on content updates.
    """
    # Load from database
    pass

# 4. PROGRESS TRACKING (High Frequency)
# Batch updates to reduce database writes

class ProgressBatcher:
    """
    Batch progress updates to database.
    Flushes every 5 seconds or 100 updates.
    """
    def __init__(self):
        self.pending_updates = []
        self.last_flush = time.time()
    
    async def add_update(self, user_id, content_id, percentage):
        self.pending_updates.append({
            "user_id": user_id,
            "content_id": content_id,
            "percentage": percentage
        })
        
        if len(self.pending_updates) >= 100 or time.time() - self.last_flush > 5:
            await self.flush()
    
    async def flush(self):
        # Bulk update database
        pass

# 5. EXPORT CACHING
# Cache generated PDFs for 10 minutes

@router.post("/artifacts/{artifact_id}/export/pdf")
async def export_pdf_cached(artifact_id: str, redis: Redis = Depends(get_redis)):
    """
    Check Redis cache before generating PDF.
    Cache key: f"pdf:{artifact_id}:{artifact.updated_at}"
    """
    cache_key = f"pdf:{artifact_id}:{artifact.updated_at}"
    
    cached_pdf = await redis.get(cache_key)
    if cached_pdf:
        return StreamingResponse(BytesIO(cached_pdf), media_type="application/pdf")
    
    # Generate PDF
    pdf_bytes = await orchestrator.export_artifact(artifact_id, "PDF")
    
    # Cache for 10 minutes
    await redis.setex(cache_key, 600, pdf_bytes)
    
    return StreamingResponse(BytesIO(pdf_bytes), media_type="application/pdf")
```

---

## SUMMARY & IMPLEMENTATION CHECKLIST

### **What This Document Provides**

✅ **Complete database schema** for canvas system (6 tables)
✅ **Core services** (Orchestrator, Factory, Template Engine, Export Engine)
✅ **TwinScience content service** (64-piece content management)
✅ **Complete API endpoints** (20+ routes)
✅ **4 production templates** (Weekly, Monthly, Adaa, QBR in JSON TDL)
✅ **Agent integration** (Layer 4 creates artifacts)
✅ **Content storage strategy** (embed vs link recommendations)
✅ **Testing strategy** (unit tests + performance optimization)

### **Implementation Checklist**

**Phase 1: Database & Models (Week 1)**
- [ ] Create 6 canvas tables (migrations)
- [ ] Add SQLAlchemy ORM models
- [ ] Seed 4 system templates
- [ ] Seed TwinScience content (64 pieces)
- [ ] Create default brand kit

**Phase 2: Core Services (Week 1-2)**
- [ ] Implement CanvasOrchestrator
- [ ] Implement ArtifactFactory
- [ ] Implement TemplateEngine
- [ ] Implement ExportEngine (WeasyPrint + python-docx)
- [ ] Implement TwinScienceService

**Phase 3: API Endpoints (Week 2)**
- [ ] Artifact CRUD endpoints
- [ ] Version control endpoints
- [ ] Export endpoints (PDF/DOCX)
- [ ] TwinScience content endpoints
- [ ] Progress tracking endpoints
- [ ] Template management endpoints
- [ ] Branding endpoints

**Phase 4: Agent Integration (Week 2-3)**
- [ ] Enhance Layer 4 with artifact creation
- [ ] Add output type detection
- [ ] Add template data extraction
- [ ] Update agent prompts

**Phase 5: Testing & Optimization (Week 3)**
- [ ] Unit tests for all services
- [ ] Integration tests for API
- [ ] Performance optimization
- [ ] Export caching
- [ ] Progress batching

**Dependencies:**
```bash
# Install required packages
pip install weasyprint python-docx Pillow Jinja2

# For WeasyPrint (system dependencies)
apt-get install -y libpango-1.0-0 libpangocairo-1.0-0
```

---

## NEXT DOCUMENT

**Document 14: Canvas Frontend** will cover:
- React components for canvas workspace
- Layout mode switching (chat-dominant, expanded, fullscreen)
- Artifact renderers for each type
- TwinScience content navigator UI
- Modal overlay for content viewing
- Export UI and download handlers
- Mobile responsive design (chat only, canvas desktop-only)

**Estimated complexity:** HIGH (2-3 weeks)

---

END OF DOCUMENT 13: CANVAS SYSTEM - BACKEND ARCHITECTURE
